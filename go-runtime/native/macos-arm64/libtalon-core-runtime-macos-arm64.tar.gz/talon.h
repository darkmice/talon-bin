/*
 * Copyright (c) 2026 Talon Contributors
 * Author: dark.lijin@gmail.com
 * Licensed under the Talon Community Dual License Agreement.
 * See the LICENSE file in the project root for full license information.
 */
/**
 * Talon — 面向本地 AI 的多模融合数据引擎
 * C ABI 头文件
 *
 * 用法：链接 libtalon.dylib / libtalon.so / talon.dll
 * 所有函数返回 0 表示成功，-1 表示失败（除 talon_open 返回指针）。
 */

#ifndef TALON_H
#define TALON_H

#include <stddef.h>
#include <stdint.h>

/** Version of the JSON storage conditional-batch contract. */
#define TALON_STORAGE_CONDITIONAL_BATCH_VERSION 1u
/** Version of the durable idempotent conditional transaction contract. */
#define TALON_STORAGE_CONDITIONAL_TRANSACTION_VERSION 2u
/** Version of the compact durable conditional-transaction receipt contract. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_VERSION 3u
/** V3 receipt has at most this many ordered conditions. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_MAX_CONDITIONS 128u
/** V3 receipt has at most this many ordered mutations. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_MAX_MUTATIONS 128u
/** V3 condition/mutation key limit in bytes. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_MAX_KEY_BYTES (8u * 1024u)
/** V3 durable compact receipt maximum serialized size. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_MAX_RECEIPT_BYTES (16u * 1024u * 1024u)
/** Version of the TLNCTX3 compact conditional-command digest encoding. */
#define TALON_STORAGE_CONDITIONAL_COMPACT_RECEIPT_DIGEST_VERSION 1u
/** Version of the TLNCTX2 conditional-command digest encoding. */
#define TALON_STORAGE_CONDITIONAL_COMMAND_DIGEST_VERSION 1u
/** Version of storage/conditional_get snapshot-bound point reads. */
#define TALON_STORAGE_CONDITIONAL_POINT_READ_VERSION 1u
/** Immutable legacy version of bounded same-snapshot multi-key reads. */
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_VERSION 1u
/** 1024-key version of bounded same-snapshot multi-key reads (covering enterprise governance facts). */
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_VERSION_V2 2u
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_V1_MAX_KEYS 128u
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_V2_MAX_KEYS 1024u
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_MAX_REQUEST_BYTES (512u * 1024u)
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_MAX_TOTAL_VALUE_BYTES (8u * 1024u * 1024u)
#define TALON_STORAGE_CONDITIONAL_SNAPSHOT_READ_MAX_RESPONSE_BYTES (16u * 1024u * 1024u)
/** Version of the revision-bound conditional namespace prefix scan. */
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_VERSION 1u
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_ENTRIES 256u
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_PREFIX_BYTES (8u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_KEY_BYTES (64u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_REQUEST_BYTES (64u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_VALUE_BYTES (3u * 1024u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_TOTAL_VALUE_BYTES (8u * 1024u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_RESPONSE_BYTES (16u * 1024u * 1024u)
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_MAX_ACTIVE_CURSORS 4096u
#define TALON_STORAGE_CONDITIONAL_PREFIX_SCAN_CURSOR_TTL_SECS 300u
/** Immutable revision stream/time-index wire protocol version. */
#define TALON_REVISION_STREAM_VERSION 2u
/** Version of the stable Talon native C ABI profile. */
#define TALON_NATIVE_ABI_VERSION 1u
/** Binary-safe reads over the existing KV string keyspace. */
#define TALON_NATIVE_KV_READ_VERSION 1u
/** Version of the JSON returned by talon_build_manifest. */
#define TALON_NATIVE_BUILD_MANIFEST_VERSION 2u

#ifdef __cplusplus
extern "C" {
#endif

/** 不透明数据库句柄。 */
typedef struct TalonHandle TalonHandle;

/**
 * 打开数据库；成功返回句柄指针，失败返回 NULL。
 * @param path  数据目录路径（null-terminated UTF-8）
 */
TalonHandle *talon_open(const char *path);

/**
 * 关闭数据库并释放句柄。
 * @param handle  talon_open 返回的指针，只能调用一次。
 */
void talon_close(TalonHandle *handle);

/**
 * 执行 SQL 语句；结果以 JSON 写入 *out_json。
 * @param handle    数据库句柄
 * @param sql       SQL 语句（null-terminated UTF-8）
 * @param out_json  成功时写入 JSON 字符串指针，需用 talon_free_string 释放
 * @return 0 成功，-1 失败
 */
int talon_run_sql(const TalonHandle *handle, const char *sql, char **out_json);

/**
 * Execute SQL and return rows in the stable little-endian TLV v1 encoding.
 * Output starts with row_count:u32 and col_count:u32, followed by row-major
 * typed cells. `*out_data` must be released with talon_free_bytes.
 */
int talon_run_sql_bin(const TalonHandle *handle,
                      const char *sql,
                      uint8_t **out_data,
                      size_t *out_len);

/**
 * Execute parameterized SQL without interpolating values into SQL text.
 *
 * params uses little-endian TLV v1: count:u32 followed by typed values.
 * Tags are 0 Null, 1 i64, 2 f64, 3 UTF-8 text, 4 blob, 5 bool,
 * 6 JSONB, 7 f32 vector, 8 timestamp i64, 9 geo pair f64/f64,
 * 10 date i32, 11 time i64, and 12 decimal i128 coefficient + u8 scale.
 * Length-bearing values use a u32 byte/dimension length. Trailing bytes,
 * truncated values, and malformed tags are invalid_argument. A structurally
 * valid tag 12 whose precision or scale exceeds the 38-digit limit is
 * decimal_out_of_range. Result ownership and encoding match talon_run_sql_bin.
 */
int talon_run_sql_param_bin(const TalonHandle *handle,
                            const char *sql,
                            const uint8_t *params,
                            size_t params_len,
                            uint8_t **out_data,
                            size_t *out_len);

/**
 * KV SET。
 * @param ttl_secs  TTL 秒数；<=0 表示无过期
 * @return 0 成功，-1 失败
 */
int talon_kv_set(const TalonHandle *handle,
                 const uint8_t *key, size_t key_len,
                 const uint8_t *value, size_t value_len,
                 int64_t ttl_secs);

/**
 * KV GET。
 * @param out_value  成功时写入数据指针，需用 talon_free_bytes 释放；不存在时为 NULL
 * @param out_len    数据长度；不存在时为 0
 * @return 0 成功，-1 失败
 */
int talon_kv_get(const TalonHandle *handle,
                 const uint8_t *key, size_t key_len,
                 uint8_t **out_value, size_t *out_len);

/**
 * Versioned binary-safe KV read subset. This is not the complete gredis ABI.
 * Operations: 1 GET, 2 MGET, 3 EXISTS, 4 TYPE, 5 TTL.
 * Request integers are unsigned little-endian u32. GET/TYPE/TTL accept
 * key_len:u32 + raw key. MGET/EXISTS accept count:u32 followed by that
 * many key_len:u32 + raw key records. Empty keys and values are valid.
 * GET reply: tag:u8 (0 missing, 1 present); present adds len:u32 + raw value.
 * MGET reply: count:u32 followed by GET-shaped entries in request order.
 * EXISTS reply: signed little-endian i64 count (duplicate keys count twice).
 * TYPE reply: u8 (0 missing, 1 string, including binary string values).
 * TTL reply: signed little-endian i64 seconds (-2 missing, -1 no expiry).
 * Limits: request 1 MiB, reply 64 MiB, 4096 keys, 64 KiB per key.
 * All output buffers belong to the caller and must be freed with
 * talon_free_bytes(*out_data, *out_len). On failure both outputs are zeroed.
 * The read may perform legacy lazy expiry cleanup. It does not provide a
 * cross-process snapshot or millisecond TTL semantics.
 */
int talon_kv_read_v1(const TalonHandle *handle, uint32_t operation,
                     const uint8_t *request, size_t request_len,
                     uint8_t **out_data, size_t *out_len);

/**
 * KV DEL。
 * @return 0 成功，-1 失败
 */
int talon_kv_del(const TalonHandle *handle,
                 const uint8_t *key, size_t key_len);

/**
 * KV INCRBY — 原子自增 delta 步长；key 不存在视为 0。
 * @param delta     自增步长（可为负数实现自减）
 * @param out_value 成功时写入增后的值
 * @return 0 成功，-1 失败
 */
int talon_kv_incrby(const TalonHandle *handle,
                    const uint8_t *key, size_t key_len,
                    int64_t delta, int64_t *out_value);

/**
 * KV SETNX — key 不存在时写入，已存在时不操作。
 * @param was_set  成功时写入 1（已写入）或 0（key 已存在未操作）
 * @return 0 成功，-1 失败
 */
int talon_kv_setnx(const TalonHandle *handle,
                   const uint8_t *key, size_t key_len,
                   const uint8_t *value, size_t value_len,
                   int64_t ttl_secs, int *was_set);

/**
 * 向量插入。
 * @param index_name  索引名称（null-terminated UTF-8）
 * @param id          向量 ID
 * @param vec_data    f32 数组指针
 * @param vec_dim     向量维度
 * @return 0 成功，-1 失败
 */
int talon_vector_insert(const TalonHandle *handle,
                        const char *index_name,
                        uint64_t id,
                        const float *vec_data, size_t vec_dim);

/**
 * 向量 KNN 搜索；结果以 JSON 写入 *out_json。
 * @param metric  距离度量："cosine" / "l2" / "dot"
 * @return 0 成功，-1 失败
 */
int talon_vector_search(const TalonHandle *handle,
                        const char *index_name,
                        const float *vec_data, size_t vec_dim,
                        size_t k, const char *metric,
                        char **out_json);

/**
 * Vector KNN search using the stable little-endian binary result encoding.
 * Each result occupies 12 bytes: id:u64 followed by distance:f32.
 * `*out_data` must be released with talon_free_bytes.
 */
int talon_vector_search_bin(const TalonHandle *handle,
                            const char *index_name,
                            const float *vec_data, size_t vec_dim,
                            size_t k, const char *metric,
                            uint8_t **out_data, size_t *out_len);

/**
 * Start the embedded handle's TCP server in a background thread.
 * @param tcp_addr null-terminated UTF-8 address such as "127.0.0.1:7720"
 * @return 0 on success, -1 on invalid input/start failure, -2 if already running
 */
int talon_start_server(const TalonHandle *handle, const char *tcp_addr);

/**
 * Stop and join the embedded handle's background TCP server.
 * @return 0 on success, -1 if the handle is invalid or no server is running
 */
int talon_stop_server(const TalonHandle *handle);

/**
 * 刷盘，保证此前写入持久化。
 * @return 0 成功，-1 失败
 */
int talon_persist(const TalonHandle *handle);

/** 释放 talon_run_sql / talon_vector_search 返回的 JSON 字符串。 */
void talon_free_string(char *ptr);

/** 释放二进制 ABI 返回的字节缓冲区。 */
void talon_free_bytes(uint8_t *ptr, size_t len);

/**
 * Return the current thread's last native error message. The borrowed pointer
 * remains valid until the next successful/failing native call, explicit clear,
 * or thread exit. It must not be freed.
 */
const char *talon_last_error(void);

/**
 * Return the stable machine code for the current thread's last failing native
 * call (for example sql_parse_error, not_leader, no_quorum, or uncertain).
 * The borrowed pointer follows talon_last_error lifetime rules and must not be
 * freed. Returns NULL when no native error is recorded.
 */
const char *talon_last_error_code(void);

/** Clear the current thread's borrowed error message and machine code. */
void talon_clear_last_error(void);

/**
 * Return a read-only JSON build manifest without opening a database.
 *
 * The versioned manifest binds Core semver, source commit/dirty state, target,
 * Cargo.lock hash, this header hash, ABI profile/version/required symbols,
 * compiled features, and capability status. Unadmitted HA surfaces are reported
 * as gated. `build_binding_sha256` binds those fields; release packaging must
 * separately hash the final library and bind that artifact hash to this value.
 *
 * @param out_json receives an allocated UTF-8 JSON string; free it with
 *                 talon_free_string.
 * @return 0 on success, -1 on invalid arguments or serialization failure.
 */
int talon_build_manifest(char **out_json);

/**
 * 通用 JSON 命令入口：一个函数覆盖全部引擎操作。
 *
 * 输入 JSON 格式：{"module":"kv|sql|ts|mq|vector|storage|ai|backup|stats","action":"...","params":{...}}
 * 输出 JSON 格式：{"ok":true,"data":{...}} 或
 *                 {"ok":false,"code":"stable_code","error":"..."}
 *
 * storage/conditional_batch version 1:
 * {
 *   "module":"storage",
 *   "action":"conditional_batch",
 *   "params":{
 *     "version":1,
 *     "request_id":"stable-client-id",
 *     "namespace":"application_namespace",
 *     "conditions":[{"key":[...],"expected":[...]|null,
 *                    "operator":"eq|ne|lt|le|gt|ge"}],
 *     "mutations":[{"op":"put","key":[...],"value":[...]},
 *                  {"op":"delete","key":[...]}]
 *   }
 * }
 *
 * request_id is required when native quorum is configured. Keys and values are
 * JSON byte arrays. Comparisons and all mutations execute
 * in one native serializable transaction. Missing values sort below present
 * values; numeric ordering therefore requires fixed-width big-endian encoding.
 * Remote namespaces are isolated from Talon internal keyspaces.
 *
 * Applied result:
 *   {"ok":true,"data":{"result":"applied","applied":true}}
 * Predicate-false result (no mutation):
 *   {"ok":true,"data":{"result":"condition_failed","applied":false,
 *                       "condition_failed_index":0}}
 * In native quorum mode, successful data also includes an
 * applied/quorum_fsync receipt. Errors additionally use stable not_leader,
 * no_quorum, fenced, timeout, persistence_failed, and uncertain codes. Quorum
 * conditional-write errors also include term and leader_hint (validated voter
 * node_id/address when known).
 * Other stable codes include unsupported_version, invalid_request,
 * invalid_namespace, conflict, storage_error, and unsupported_action.
 * Applications must branch on result/code, never localized error text.
 * Version 1 does not return atomic before/after observations, a standalone
 * revision, or an explicit duplicate bit. Version 2 requires request_id in
 * standalone and HA modes. Within conditions and mutations separately, each
 * (namespace,key) may appear at most once; using the same key once as a
 * condition and once as a mutation is valid CAS. Empty byte-array keys are
 * rejected as invalid_request before transaction or Raft-log mutation. Version
 * 2 additionally accepts
 *   {"op":"increment","key":[...],"delta":"signed-i64"}
 * where counters are absent-as-zero signed big-endian i64 values. It returns a
 * durable receipt containing exact condition/mutation before+after byte arrays,
 * counter before_i64/after_i64, a monotonic fencing revision, outcome, conflict
 * detail, command_sha256, and receipt_sha256. revision and all i64 convenience
 * fields, including the nested receipt, are canonical decimal JSON strings,
 * never JSON numbers, so JS/TS consumers preserve values outside the 53-bit
 * safe integer range. receipt_sha256 hashes that canonical wire receipt with
 * receipt_sha256 set to the empty string. In v2 responses the outer quorum
 * receipt index and term are decimal strings for the same reason. An exact
 * command_sha256 uses TALON_STORAGE_CONDITIONAL_COMMAND_DIGEST_VERSION 1:
 * SHA-256 over "TLNCTX2", version:u16le, condition_count:u32le, then each
 * ordered condition as length-prefixed keyspace/key, expected-presence:u8,
 * optional expected bytes, and operator:u8 (eq=0, ne=1, lt=2, le=3, gt=4,
 * ge=5); followed by mutation_count:u32le and each ordered mutation as op:u8
 * (put=0, delete=1, increment=2), length-prefixed keyspace/key, then a
 * length-prefixed put value or increment delta:i64le. A length prefix is u32le.
 * request_id is intentionally excluded from the v2 command_sha256 and MUST be
 * compared separately; receipt_sha256 binds it into the complete receipt. SDKs
 * must check both identities and all receipt observations, not command_sha256
 * alone.
 * An exact
 * receipt is limited to 16 MiB and oversized requests fail before user mutation
 * or Raft log append. The outer
 * result is applied, duplicate, or conflict; original_result distinguishes the
 * durable first outcome on an identical retry. A request_id rebound to another
 * payload fails with code conflict. An acknowledgement failure after a possible
 * commit fails with code uncertain and must be resolved by querying:
 *   {"module":"storage","action":"conditional_receipt",
 *    "params":{"request_id":"stable-client-id"}}
 * When the durable transaction was a revision_stream_append, a found standalone
 * or native-quorum receipt also includes the original stream_receipt. Recovery
 * does not re-run the append or allocate a new revision.
 * SDKs must not synthesize any v2 field with reads, locks, SETNX, or SQL text.
 *
 * Version 3 is an explicit compact-receipt contract, never a v2 fallback. It
 * uses the same request shape and atomic conditional write, but the receipt
 * contains ordered condition/mutation observations with key identity,
 * operation, before/after {present,length,sha256}, optional increment i64
 * metadata, outcome/conflict, command_sha256, revision, and receipt_sha256.
 * Values are never embedded in a v3 receipt. V3 permits at most 128 conditions
 * and 128 mutations and each key is at most 8192 bytes; this bounds receipt
 * metadata below the 16 MiB durable-result limit independently of value sizes.
 * V3 conditions are restricted to eq and ne: a SHA-256 value commitment cannot
 * independently prove lt/le/gt/ge ordering without revealing values or adding
 * a separate ordered-proof protocol. Its command_sha256 is SHA-256 over
 * "TLNCTX3", version:u16le, length-prefixed request_id, then the same ordered
 * condition/mutation encoding above. receipt_sha256 is an unkeyed integrity
 * digest of the canonical receipt with that field empty. It is NOT a signature,
 * MAC, or remote-server authentication; transport, artifact and quorum trust
 * must be established separately.
 * The HTTP Server rejects bodies above 64 MiB. This transport limit does not
 * apply to a caller-owned talon_execute C buffer; such callers must set their
 * own input allocation policy before invoking the ABI.
 * `conditional_receipt` returns the original receipt version unchanged after a
 * lost response, restart, or HA leadership change. SDKs must request version 3
 * explicitly and reject a v2 receipt for a v3 request (and vice versa).
 *
 * Snapshot-bound conditional point reads use the separate action:
 *   {"module":"storage","action":"conditional_get","params":{
 *     "version":1,"namespace":"user-conditional-namespace","key":[...],
 *     "revision":null|"required-positive-u64"}}
 * The successful data object always echoes version, namespace, key, and the
 * required-nullable revision. value is required and is null exactly when the key
 * is absent in the returned MVCC snapshot; an empty byte array remains [].
 * observed_revision and snapshot_revision are canonical decimal strings.
 * observed_revision is the standalone conditional-v2 sequence or native-quorum
 * last_applied watermark read in the same snapshot as value. A non-null revision
 * is a lower bound: if the local snapshot has not applied it, the action returns
 * snapshot_not_available; the action does not claim an exact historical read.
 * snapshot_revision identifies the local Fjall MVCC read view and is not a Raft
 * index or portable fencing token. response_sha256 binds every response field;
 * SDKs must still compare all echoed request fields and require
 * observed_revision >= revision. This is a snapshot read, not ReadIndex: without
 * a required receipt revision it may be stale on a follower. Stable errors are
 * unsupported_version, invalid_namespace, invalid_request, request_too_large,
 * result_too_large, snapshot_not_available, corrupt_state, and storage_error.
 * Keys are limited to 64 KiB, values to 3 MiB, canonical params to 512 KiB, and
 * the JSON response to 16 MiB. Legacy storage/get remains unchanged.
 *
 * Bounded same-snapshot multi-key reads use:
 *   {"module":"storage","action":"conditional_snapshot_get","params":{
 *     "version":1|2,"namespace":"user-conditional-namespace",
 *     "keys":[[...],[...]],"revision":null|"required-positive-u64"}}
 * The response contains one ordered observation per unique request key. Every
 * value and the observed revision watermark come from one Fjall MVCC snapshot
 * and response_sha256 binds their indexes, keys, absent/empty distinction, and
 * values. This one-call batch avoids cross-call snapshot drift; it is not an
 * arbitrary historical read and its local snapshot_revision is not portable.
 * Version 1 remains byte-for-byte compatible and accepts 1..128 unique keys.
 * Version 2 accepts 1..256 and uses a distinct V2 response digest domain. Each
 * key/value follows conditional_get limits, aggregate returned values are
 * limited to 8 MiB, canonical params to 512 KiB, and the response envelope to
 * 16 MiB. The MVCC snapshot lives only for this one call and is dropped before
 * return, so there is no server-side pin, expiry, or pagination state. A retry
 * after response loss is a fresh current snapshot of the complete ordered key
 * set; it never pretends to recover the lost historical view. Error codes match
 * conditional_get.
 *
 * Revision-fenced conditional namespace discovery uses:
 *   {"module":"storage","action":"conditional_prefix_scan","params":{
 *     "version":1,"request_id":"stable-scan-attempt-id",
 *     "namespace":"user-conditional-namespace","prefix":[...],"limit":1..256,
 *     "cursor":null|"opaque-32-lowercase-hex",
 *     "revision":null|"required-positive-u64"}}
 * request_id is required and must remain identical across the initial request,
 * every continuation, and retries. A null-cursor retry recovers the original
 * leased Fjall MVCC snapshot and issued next cursor; rebinding the id returns
 * conflict. Continuation cursors are bound to every request field and expire
 * five minutes after the initial page. They are node-local, in-memory leases:
 * expiry, restart, or node/leader change returns cursor_unavailable and never
 * resumes against a fresh snapshot. At most 4096 combined start/continuation
 * states are retained. Prefixes are 1..8192 bytes, keys are at most 64 KiB, a
 * value is at most 3 MiB, aggregate page values are at most 8 MiB, canonical
 * params are at most 64 KiB, and the response budget is 16 MiB. The full digest
 * encoding and retry contract are specified in conditional-prefix-scan-v1.md.
 *
 * Immutable revision stream v2 uses the same function with:
 *   {"module":"storage","action":"revision_stream_append","params":{
 *     "version":2,"request_id":"stable-id","namespace":"side-facts",
 *     "stream_id":[...],"expected_head":null|{
 *       "revision":"u64","last_occurred_at":"i64","root_sha256":"64hex",
 *       "proof":{"version":1,"leaf_count":"u64","root_sha256":"64hex",
 *         "last_content_sha256":"64hex","peaks":[
 *           {"height":0..63,"start_revision":"u64","root_sha256":"64hex"}]}}},
 *     "revision":"u64","occurred_at":"i64","payload":[...],
 *     "side_conditions":[{"key":[...],"expected":null|[...],"operator":"eq|ne|lt|le|gt|ge"}],
 *     "side_mutations":[{"op":"put|delete|increment","key":[...],
 *       "value":[...],"delta":"i64"}]}}
 * stream_id and payload are JSON byte arrays. revision/occurred_at/delta and
 * every 64-bit response field are canonical decimal strings. expected_head is
 * a required field: it is null only for revision 1; otherwise
 * revision must equal expected_head+1 and
 * occurred_at must be nondecreasing. Payload is limited to 1 MiB and side items
 * have a 4 MiB aggregate limit; at most 128 side conditions and 128
 * side mutations are accepted. Side items are confined to the named user
 * namespace and cannot address Talon internal keyspaces.
 *
 * Time-range reads use:
 *   {"module":"storage","action":"revision_stream_query","params":{
 *     "version":2,"stream_id":[...],"from_occurred_at":"i64",
 *     "until_occurred_at":"i64","pinned_head":null|{...},
 *     "after_revision":null|"u64","limit":1..1000}}
 * pinned_head and after_revision are required nullable fields. The first request
 * sends both as null. The first response returns pinned_head; every later page
 * must resend that pinned_head and set after_revision to the prior continuation.
 * observed_live_head may advance, while pinned_head and
 * query_window_first_revision/query_window_last_revision stay fixed.
 * page_first_revision/page_last_revision describe only this page;
 * next_after_revision is the cursor when has_more=true. Entries contain
 * revision, occurred_at, payload, payload_sha256, previous_root_sha256,
 * content_sha256, proof_root_sha256, and root_sha256. `proof` uses scheme
 * talon_mmr_sha256_v1 and contains authenticated window neighbors/endpoints,
 * an optional immediate page successor, and one canonical inclusion path per
 * returned entry. These fields let an SDK reject payload, head, window,
 * continuation, cross-stream, downgrade, and checkpoint substitution without
 * replaying from revision 1. A query
 * response has a conservative 16 MiB JSON-wire budget; reaching it
 * returns a continuation, while one entry exceeding it is invalid_request.
 * A lagging
 * replica returns snapshot_not_available. Other stable outcomes/codes include
 * applied, duplicate, conflict, invalid_request, corrupt_stream, uncertain,
 * and persistence_failed. The dedicated stream keyspace is append-only through
 * this contract; generic storage/KV/SQL writes cannot update or delete it.
 * Version 1 remains readable/appendable for compatibility, keeps its linear
 * chain verifier, and cannot be silently upgraded to or mixed with v2. Capability
 * discovery reports revision_stream v2 as gated until SDK/cross-target,
 * recovery, capacity, and adversarial soak evidence are complete.
 *
 * Server HA retry/status lookup uses:
 *   {"module":"cluster","action":"request_receipt",
 *    "params":{"request_id":"stable-client-id"}}
 * A found receipt includes version, request_id, term, index, command_sha256,
 * stage (accepted|committed|applied), durability
 * (none|local_fsync|quorum_fsync), and applied result/result_sha256 when known.
 * term and index are canonical decimal JSON strings.
 * Missing and unavailable receipts use stable not_found, not_configured, or
 * storage_error codes. A receipt is derived from the consensus log and does not
 * independently authorize a write.
 *
 * @param handle    数据库句柄
 * @param cmd_json  JSON 命令字符串（null-terminated UTF-8）
 * @param out_json  成功时写入 JSON 结果指针，需用 talon_free_string 释放
 * @return 0 成功（含业务错误），-1 仅在句柄/参数无效时返回
 */
int talon_execute(const TalonHandle *handle, const char *cmd_json, char **out_json);

#ifdef __cplusplus
}
#endif

#endif /* TALON_H */
